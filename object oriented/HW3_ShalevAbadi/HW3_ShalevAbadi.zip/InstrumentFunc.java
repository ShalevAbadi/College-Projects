/**
 * Created By: Grigory Shaulov
 */
public interface InstrumentFunc  extends Cloneable, Comparable<MusicalInstrument>{

}
