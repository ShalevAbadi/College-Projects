//Shalev Abadi 205740772
public interface InstrumentFunc<T extends MusicalInstrument> extends Cloneable, Comparable<T> {

}
